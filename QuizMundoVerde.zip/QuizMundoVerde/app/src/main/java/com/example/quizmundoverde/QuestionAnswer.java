package com.example.quizmundoverde;

public class QuestionAnswer {

    public static String[] question ={
        "O Brasil é exemplo em reciclagem de:",
        "Os recursos naturais são finitos, quais citados abaixo é o mais prejudicado atualmente?",
        "Marque a alternativa em que todos os materiais/objetos que não podem ser reciclados?"
    };

    public static String[][] choices = {
            {"Garrafas Plásticas(PET)","Lata de Alumínio","Papel para uso escolar","Vidros"},
            {"Água", "Petróleo", "Carvão", "Gás Natural"},
            {"Revistas, Livros e Listas Telefônicas", "Cadernos, Cartolinas e Lista telefônica", "Fotográfias, Papel vegetal e Carbono", "Carbono, Fotográfias e Celofane"}
    };

    public static String[] correctAnswers = {
            "Papel para uso escolar",
            "Água",
            "Carbono, Fotográfias e Celofane"
    };

}
